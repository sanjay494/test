const express=require('express');
const app=express();
const mongoose=require('mongoose');

const postRoute=require('./routes/posts');
const bodyParser=require('body-parser');
//app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.urlencoded({'extended':'true'}));            // parse application/x-www-form-urlencoded
app.use(bodyParser.json());                                     // parse application/json


app.use('/posts',postRoute);
//app.use(express.bodyParser());


//middlewares

// app.use('/posts',()=>{
// 	console.log("this is middleware running");
// })


//mongoose.connect("mongodb://localhost:27017/test"); //Test is the database name. 


mongoose.connect('mongodb://localhost:27017/test',
	{ useNewUrlParser: true },
	()=>console.log('connected to db')
)
app.listen(3000);
