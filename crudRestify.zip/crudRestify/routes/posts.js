const express=require('express');
const router=express.Router();
const Post=require('../models/Post');

// router.post('/',(req,res)=>{
// 	console.log("req.body"+req.body);
// })

router.get('/', async(req,res)=>{
	//res.send("welcome to my posts");
	try{
		//console.log("request"+req);
		const post=await Post.find();
		res.json(post);
	}catch(err){
		//console.log(err);
	}
});

router.post('/',(req,res)=>{
console.log("req"+JSON.stringify(req.body));
//process.exit();
const post=new Post({
	title : req.body.title,
	description : req.body.description
})

try{
//console.log("Post"+Post);
console.log("hhhhhhhh"+post);
post.save()
.then(data=>{
	res.json(data);
	res.send("hiii");
}).catch(ex=>{
	console.log("ex"+ex);
})
//console.log("gggggggggggg"+savepost);
//res.json("savepost"+savepost);
}catch(err){
	res.json("errr"+err);
	res.send("eeeeerrrrr");
}
})

router.get('/:postId',async(req,res)=>{
	try{
		//console.log("request"+JSON.stringify(req.params));
		const post=await Post.findById(req.params.postId);
		res.json(post);
	}catch(err){
		console.log(err);
	}
})

module.exports=router;